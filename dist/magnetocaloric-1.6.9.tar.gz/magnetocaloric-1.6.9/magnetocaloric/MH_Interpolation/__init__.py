from .interpol import interpol

__all__ = [
    'interpol'
]